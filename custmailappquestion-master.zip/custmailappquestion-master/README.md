# custmailappquestion
This is an exercise question for the class Component-Based Software Development.
The student task is to fork this repository and complete the program.
