/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

package javaapplication1;
import java.util.Scanner;
/**
 *
 * @author LENOVO
 */
public class Foot {

    /**
     * @param args the command line arguments
     */
    private FootShape fs;
    public static void main(String[] args) {
        // TODO code application logic here
        Foot foot = new Foot();
        //FootShape fs= new FootShape();
        Scanner sc = new Scanner(System.in);
        System.out.print("What to draw? 1. Ellipse, 2. Rectangle --");
        int i = sc.nextInt();
        foot.draw(i);
        
    }
    public void draw(int i){
        this.fs = new FootShape();
        switch(i) {
            case 1:
                System.out.println(fs.drawAsEllipse());
                break;
            case 2:
                System.out.println(fs.drawAsRectange());
                break;
        }
    }
}
